This directory is for generated files from the compiler
